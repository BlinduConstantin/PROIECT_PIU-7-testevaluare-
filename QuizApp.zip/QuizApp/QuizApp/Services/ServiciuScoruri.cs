using System.Text.Json;
using QuizApp.Models;
using System.IO;
namespace QuizApp.Services;

/// <summary>
/// Gestionează persistența scorurilor și a utilizatorului curent.
/// Fișiere:
///   %AppData%\QuizApp\scoruri.json         — toate scorurile
///   %AppData%\QuizApp\utilizator_curent.txt — numele utilizatorului activ
/// </summary>
public static class ServiciuScoruri
{
    private static readonly string _folder =
        Path.Combine(Environment.GetFolderPath(
            Environment.SpecialFolder.ApplicationData), "QuizApp");

    private static readonly string _fisierScoruri   = Path.Combine(_folder, "scoruri.json");
    private static readonly string _fisierUtilizator= Path.Combine(_folder, "utilizator_curent.txt");

    private static readonly JsonSerializerOptions _optCitire  = new() { PropertyNameCaseInsensitive = true };
    private static readonly JsonSerializerOptions _optScriere = new() { WriteIndented = true };

    // ── Utilizator curent ─────────────────────────────────────────────────────

    public static string UtilizatorCurent { get; private set; } = IncarcaUtilizator();

    private static string IncarcaUtilizator()
    {
        try
        {
            if (File.Exists(_fisierUtilizator))
                return File.ReadAllText(_fisierUtilizator).Trim();
        }
        catch { }
        return "";
    }

    public static void SeteazaUtilizator(string nume)
    {
        UtilizatorCurent = nume.Trim();
        try
        {
            Directory.CreateDirectory(_folder);
            File.WriteAllText(_fisierUtilizator, UtilizatorCurent);
        }
        catch { }
    }

    // ── Scoruri ───────────────────────────────────────────────────────────────

    public static List<ScorSalvat> IncarcaScoruri()
    {
        try
        {
            if (!File.Exists(_fisierScoruri)) return [];
            string json = File.ReadAllText(_fisierScoruri);
            return JsonSerializer.Deserialize<List<ScorSalvat>>(json, _optCitire) ?? [];
        }
        catch { return []; }
    }

    public static void SalveazaScor(ScorSalvat scor)
    {
        try
        {
            Directory.CreateDirectory(_folder);
            var lista = IncarcaScoruri();
            lista.Add(scor);
            File.WriteAllText(_fisierScoruri, JsonSerializer.Serialize(lista, _optScriere));
        }
        catch { }
    }

    public static void StergeToateScorurile()
    {
        try { File.Delete(_fisierScoruri); }
        catch { }
    }

    /// <summary>Returnează scorurile sortate descrescător, cu opțional filtru pe domeniu.</summary>
    public static List<ScorSalvat> ObtineTopScoruri(string? filtruDomeniu = null, int maxRanduri = 100)
    {
        var toate = IncarcaScoruri();
        var filtrate = string.IsNullOrEmpty(filtruDomeniu)
            ? toate
            : toate.Where(s => s.NumeDomeniu == filtruDomeniu).ToList();
        return filtrate
            .OrderByDescending(s => s.Procent)
            .ThenByDescending(s => s.Scor)
            .ThenByDescending(s => s.DataOra)
            .Take(maxRanduri)
            .ToList();
    }

    /// <summary>Returnează lista de domenii distincte din istoricul de scoruri.</summary>
    public static List<string> ObtineDoméniiDinIstoricScoruri() =>
        IncarcaScoruri()
            .Select(s => s.NumeDomeniu)
            .Distinct()
            .OrderBy(n => n)
            .ToList();
}
