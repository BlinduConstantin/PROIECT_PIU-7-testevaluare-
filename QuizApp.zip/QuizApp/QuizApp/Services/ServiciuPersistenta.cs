using System.Text.Json;
using QuizApp.Models;
using System.IO;
namespace QuizApp.Services;

/// <summary>
/// Salvează și încarcă domeniile create de utilizator din:
///   %AppData%\QuizApp\domenii_salvate.json
///
/// Domeniile built-in (din QuizData.cs) NU sunt salvate —
/// ele sunt întotdeauna recreate din cod la pornire.
/// </summary>
public static class ServiciuPersistenta
{
    private static readonly string _folderDate = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "QuizApp");

    private static readonly string _fisierDomenii = Path.Combine(
        _folderDate, "domenii_salvate.json");

    private static readonly JsonSerializerOptions _optiuniCitire = new()
    {
        PropertyNameCaseInsensitive = true,
    };

    private static readonly JsonSerializerOptions _optiuniScriere = new()
    {
        WriteIndented = true,
    };

    // ── Calea fișierului (afișată în UI) ─────────────────────────────────────
    public static string CaleFisier => _fisierDomenii;

    // ── Încărcare ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Încarcă lista de domenii salvate anterior.
    /// Returnează o listă goală dacă fișierul nu există sau e corupt.
    /// </summary>
    public static List<DomeniuQuiz> IncarcaDomeniiSalvate()
    {
        try
        {
            if (!File.Exists(_fisierDomenii)) return [];

            string json = File.ReadAllText(_fisierDomenii);
            return JsonSerializer.Deserialize<List<DomeniuQuiz>>(json, _optiuniCitire) ?? [];
        }
        catch
        {
            return [];
        }
    }

    // ── Salvare ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Suprascrie fișierul de persistență cu lista curentă de domenii personalizate.
    /// Operațiunea eșuează silențios dacă apare o eroare de I/O.
    /// </summary>
    public static bool SalveazaDomenii(IEnumerable<DomeniuQuiz> domenii)
    {
        try
        {
            Directory.CreateDirectory(_folderDate);
            string json = JsonSerializer.Serialize(domenii.ToList(), _optiuniScriere);
            File.WriteAllText(_fisierDomenii, json);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
