using System.Windows;
using System.Windows.Controls;
using QuizApp.Models;
using QuizApp.Services;
using QuizApp.ViewModels;

namespace QuizApp.Views;

public partial class ClasamentWindow : Window
{
    private const string _TOATE = "— Toate domeniile —";

    public ClasamentWindow()
    {
        InitializeComponent();

        tbSubtitlu.Text = $"Utilizator curent: 👤 {ServiciuScoruri.UtilizatorCurent}";

        IncarcaFiltruDomenii();
        ActualizeazaClasament();
    }

    // ── Filtru domenii ────────────────────────────────────────────────────────

    private void IncarcaFiltruDomenii()
    {
        cbFiltruDomeniu.Items.Add(_TOATE);
        foreach (var d in ServiciuScoruri.ObtineDoméniiDinIstoricScoruri())
            cbFiltruDomeniu.Items.Add(d);
        cbFiltruDomeniu.SelectedIndex = 0;
    }

    private void LaSchimbareFiltru(object sender, SelectionChangedEventArgs e)
        => ActualizeazaClasament();

    // ── Actualizare tabel ─────────────────────────────────────────────────────

    private void ActualizeazaClasament()
    {
        string? filtru = cbFiltruDomeniu.SelectedItem?.ToString() == _TOATE
            ? null
            : cbFiltruDomeniu.SelectedItem?.ToString();

        var scoruri = ServiciuScoruri.ObtineTopScoruri(filtru);

        bdGol.Visibility    = scoruri.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        listScoruri.Visibility = scoruri.Count > 0 ? Visibility.Visible : Visibility.Collapsed;

        // Construim randurile cu ViewModel
        string utilizatorCurent = ServiciuScoruri.UtilizatorCurent;

        var randuri = scoruri.Select((s, i) => new RandClasament
        {
            Scor                 = s,
            Loc                  = i + 1,
            EsteUtilizatorCurent = s.Utilizator.Equals(
                utilizatorCurent, StringComparison.OrdinalIgnoreCase),
        }).ToList();

        listScoruri.ItemsSource = randuri;

        // Actualizăm podiumul
        ActualizeazaPodium(scoruri);
    }

    private void ActualizeazaPodium(List<ScorSalvat> scoruri)
    {
        void Set(Border bd, TextBlock tbN, TextBlock tbS, int idx)
        {
            if (scoruri.Count > idx)
            {
                var s = scoruri[idx];
                tbN.Text = s.Utilizator;
                tbS.Text = $"{s.Procent:F0}% · {s.NumeDomeniu}";
                bd.Visibility = Visibility.Visible;
            }
            else bd.Visibility = Visibility.Collapsed;
        }

        Set(bdLoc1, tbLoc1Utilizator, tbLoc1Scor, 0);
        Set(bdLoc2, tbLoc2Utilizator, tbLoc2Scor, 1);
        Set(bdLoc3, tbLoc3Utilizator, tbLoc3Scor, 2);
    }

    // ── Butoane ───────────────────────────────────────────────────────────────

    private void LaStergereScoruri(object sender, RoutedEventArgs e)
    {
        var confirmare = MessageBox.Show(
            "Ștergi TOATE scorurile din clasament?\nAceastă acțiune nu poate fi anulată.",
            "Confirmare ștergere",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (confirmare != MessageBoxResult.Yes) return;

        ServiciuScoruri.StergeToateScorurile();

        // Reîncarcă filtrul și tabelul
        cbFiltruDomeniu.Items.Clear();
        IncarcaFiltruDomenii();
        ActualizeazaClasament();
    }

    private void LaInchidere(object sender, RoutedEventArgs e) => Close();
}
