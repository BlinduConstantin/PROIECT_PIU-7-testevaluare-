using System.Windows;
using System.Windows.Input;

namespace QuizApp.Views;

public partial class DialogUtilizator : Window
{
    public string NumeUtilizator { get; private set; } = "";

    /// <param name="numeInitial">Pre-populează câmpul dacă utilizatorul schimbă numele.</param>
    public DialogUtilizator(string numeInitial = "")
    {
        InitializeComponent();
        tbNume.Text = numeInitial;
        Loaded += (_, _) =>
        {
            tbNume.Focus();
            tbNume.SelectAll();
        };
    }

    private void LaOk(object sender, RoutedEventArgs e) => Confirma();

    private void LaApasareTasta(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)  Confirma();
        if (e.Key == Key.Escape) Close();
    }

    private void LaSchimbareText(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        tbEroare.Visibility = System.Windows.Visibility.Collapsed;
    }

    private void Confirma()
    {
        string nume = tbNume.Text.Trim();
        if (string.IsNullOrEmpty(nume))
        {
            tbEroare.Text       = "Numele nu poate fi gol.";
            tbEroare.Visibility = System.Windows.Visibility.Visible;
            tbNume.Focus();
            return;
        }

        NumeUtilizator = nume;
        DialogResult   = true;
        Close();
    }
}
