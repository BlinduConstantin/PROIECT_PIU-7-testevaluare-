using System.Windows;
using System.Windows.Media;
using QuizApp.Models;
using QuizApp.Services;
using QuizApp.ViewModels;

namespace QuizApp.Views;

public partial class ResultsWindow : Window
{
    private readonly DomeniuQuiz         _domeniu;
    private readonly List<TentativaQuiz> _tentative;
    private readonly int                 _scor;
    private readonly string              _utilizator;

    public ResultsWindow(
        DomeniuQuiz         domeniu,
        List<TentativaQuiz> tentative,
        int                 scor,
        string              utilizator = "")
    {
        InitializeComponent();

        _domeniu    = domeniu;
        _tentative  = tentative;
        _scor       = scor;
        _utilizator = utilizator;

        Title = $"Rezultate — {_domeniu.Nume}";

        CompleteazaSumar();
        CompleteazaRevizuire();
        SalveazaScorInClasament();

        Loaded += (_, _) => ActualizeazaBaraProgres();
        SizeChanged += (_, _) => ActualizeazaBaraProgres();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SUMAR
    // ═══════════════════════════════════════════════════════════════════════════

    private void CompleteazaSumar()
    {
        int    scorMaxim = _tentative.Sum(t => t.Intrebare.Puncte);
        int    corecte   = _tentative.Count(t => t.EsteCorect);
        double procent   = scorMaxim > 0 ? 100.0 * _scor / scorMaxim : 0;

        (string medalie, string mesaj, Color culoare) = procent switch
        {
            >= 90 => ("🥇", "Excelent! Performanță remarcabilă!",    Color.FromRgb(39,  174, 96)),
            >= 75 => ("🥈", "Foarte bine! Mai ai puțin până la top!",Color.FromRgb(220, 200, 60)),
            >= 55 => ("🥉", "Bine! Continuă să exersezi!",           Color.FromRgb(210, 150, 80)),
            >= 40 => ("📖", "Aproape! Încearcă din nou!",            Color.FromRgb(180, 140, 90)),
            _     => ("📚", "Mai ai de studiat. Nu te descuraja!",   Color.FromRgb(192,  57, 43)),
        };

        tbMedalie.Text       = medalie;
        tbMesaj.Text         = mesaj;
        tbMesaj.Foreground   = new SolidColorBrush(culoare);
        tbLinieScor.Text     = $"{_scor} / {scorMaxim} puncte   ·   " +
                               $"{corecte} / {_tentative.Count} corecte   ·   {procent:F0}%";

        bdBaraUmplere.Background = new SolidColorBrush(culoare);
        bdBaraUmplere.Tag        = procent;

        butonReincercare.Content    = $"🔄  Încearcă {_domeniu.Nume} din nou";
        butonReincercare.Background = _domeniu.PensulaAccent;
    }

    private void ActualizeazaBaraProgres()
    {
        if (bdBaraUmplere.Tag is double procent && bdBaraUmplere.Parent is FrameworkElement container)
            bdBaraUmplere.Width = container.ActualWidth * procent / 100.0;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SALVARE SCOR
    // ═══════════════════════════════════════════════════════════════════════════

    private void SalveazaScorInClasament()
    {
        if (string.IsNullOrWhiteSpace(_utilizator)) return;

        int scorMaxim = _tentative.Sum(t => t.Intrebare.Puncte);
        int corecte   = _tentative.Count(t => t.EsteCorect);

        var scor = new ScorSalvat
        {
            Utilizator        = _utilizator,
            NumeDomeniu       = _domeniu.Nume,
            PictogramaDomeniu = _domeniu.Pictograma,
            Scor              = _scor,
            ScorMaxim         = scorMaxim,
            NrCorecte         = corecte,
            TotalIntrebari    = _tentative.Count,
            DataOra           = DateTime.Now,
        };

        ServiciuScoruri.SalveazaScor(scor);

        // Afișăm indicatorul "Scor salvat"
        bdScorSalvat.Visibility = Visibility.Visible;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // REVIZUIRE
    // ═══════════════════════════════════════════════════════════════════════════

    private void CompleteazaRevizuire()
    {
        var randuri = new List<RandRevizuire>();

        for (int i = 0; i < _tentative.Count; i++)
        {
            var t         = _tentative[i];
            var intrebare = t.Intrebare;
            string textCorect = intrebare.Raspunsuri[intrebare.IndiceRaspunsCorect].Text;

            Color fundalCuloare, dungaCuloare;
            SolidColorBrush culoareRaspuns, culoarePuncte;
            string pictograma, textRaspuns;

            if (t.EsteCorect)
            {
                fundalCuloare  = Color.FromRgb(15, 60, 30);
                dungaCuloare   = Color.FromRgb(39, 174, 96);
                culoareRaspuns = new SolidColorBrush(Color.FromRgb(100, 215, 130));
                culoarePuncte  = new SolidColorBrush(Color.FromRgb(39, 174, 96));
                pictograma     = "✅";
                textRaspuns    = $"✓  {textCorect}  (+{intrebare.Puncte} pct)";
            }
            else if (t.AExpirat)
            {
                fundalCuloare  = Color.FromRgb(40, 30, 10);
                dungaCuloare   = Color.FromRgb(230, 150, 40);
                culoareRaspuns = new SolidColorBrush(Color.FromRgb(230, 160, 60));
                culoarePuncte  = new SolidColorBrush(Color.FromRgb(90, 90, 120));
                pictograma     = "⏰";
                textRaspuns    = $"Timp expirat!  Răspuns corect: {textCorect}";
            }
            else
            {
                string textAles = t.RaspunsUtilizator >= 0 &&
                                  t.RaspunsUtilizator < intrebare.Raspunsuri.Count
                    ? intrebare.Raspunsuri[t.RaspunsUtilizator].Text : "—";

                fundalCuloare  = Color.FromRgb(60, 15, 12);
                dungaCuloare   = Color.FromRgb(192, 57, 43);
                culoareRaspuns = new SolidColorBrush(Color.FromRgb(230, 130, 100));
                culoarePuncte  = new SolidColorBrush(Color.FromRgb(90, 90, 120));
                pictograma     = "❌";
                textRaspuns    = $"Ales: {textAles}   |   Corect: {textCorect}";
            }

            randuri.Add(new RandRevizuire
            {
                Pictograma    = pictograma,
                TextIntrebare = $"{i + 1}. {intrebare.Text.Replace('\n', ' ')}",
                TextRaspuns   = textRaspuns,
                TextPuncte    = $"+{t.PuncteObtinute}",
                Fundal        = new SolidColorBrush(fundalCuloare),
                CuloareDunga  = new SolidColorBrush(dungaCuloare),
                CuloareRaspuns= culoareRaspuns,
                CuloarePuncte = culoarePuncte,
            });
        }

        listRevizuire.ItemsSource = randuri;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BUTOANE
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaReincercare(object sender, RoutedEventArgs e)
    {
        var fereastraQuiz = new QuizWindow(_domeniu, _utilizator);
        fereastraQuiz.Closed += (_, _) => Close();
        Hide();
        fereastraQuiz.Show();
    }

    private void LaMeniu(object sender, RoutedEventArgs e) => Close();
}
