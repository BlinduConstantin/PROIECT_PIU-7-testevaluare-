using System.Collections.ObjectModel;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using QuizApp.Data;
using QuizApp.Models;
using QuizApp.Services;
using System.IO;
namespace QuizApp.Views;

public partial class MainMenuWindow : Window
{
    private readonly List<DomeniuQuiz>               _domeniiBuiltIn;
    private readonly ObservableCollection<DomeniuQuiz> _domeniiPersonalizate;

    public MainMenuWindow()
    {
        InitializeComponent();

        _domeniiBuiltIn      = DateQuiz.ObtineDoменiiIncorporate();
        var salvate          = ServiciuPersistenta.IncarcaDomeniiSalvate();
        _domeniiPersonalizate= new ObservableCollection<DomeniuQuiz>(salvate);

        listDomeniiBuiltIn.ItemsSource       = _domeniiBuiltIn;
        listDomeniiPersonalizate.ItemsSource = _domeniiPersonalizate;

        _domeniiPersonalizate.CollectionChanged += (_, _) => ActualizeazaVizibilitatePersonalizate();
        ActualizeazaVizibilitatePersonalizate();

        // Solicităm numele utilizatorului la primul launch
        ContentRendered += LaContentRendered;
    }

    private void LaContentRendered(object? sender, EventArgs e)
    {
        ContentRendered -= LaContentRendered;

        if (string.IsNullOrEmpty(ServiciuScoruri.UtilizatorCurent))
            CereNumeUtilizator(esteObligatoriu: true);

        ActualizeazaAfisareUtilizator();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // UTILIZATOR
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaSchimbaUtilizator(object sender, RoutedEventArgs e)
    {
        CereNumeUtilizator(esteObligatoriu: false);
        ActualizeazaAfisareUtilizator();
    }

    private void CereNumeUtilizator(bool esteObligatoriu)
    {
        var dialog = new DialogUtilizator(ServiciuScoruri.UtilizatorCurent) { Owner = this };

        bool? rezultat = dialog.ShowDialog();

        if (rezultat == true)
        {
            ServiciuScoruri.SeteazaUtilizator(dialog.NumeUtilizator);
        }
        else if (esteObligatoriu && string.IsNullOrEmpty(ServiciuScoruri.UtilizatorCurent))
        {
            // Dacă nu se introduce un nume la primul launch, folosim "Anonim"
            ServiciuScoruri.SeteazaUtilizator("Anonim");
        }
    }

    private void ActualizeazaAfisareUtilizator()
    {
        tbUtilizatorCurent.Text = ServiciuScoruri.UtilizatorCurent;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CLASAMENT
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaClasament(object sender, RoutedEventArgs e)
    {
        var fereastraClasament = new ClasamentWindow { Owner = this };
        fereastraClasament.ShowDialog();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CLICK DOMENIU → QUIZ
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaClickDomeniu(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: DomeniuQuiz domeniu })
            DeschideQuiz(domeniu);
    }

    private void DeschideQuiz(DomeniuQuiz domeniu)
    {
        string utilizator = ServiciuScoruri.UtilizatorCurent;

        // Dacă cumva lipsește utilizatorul, îl solicităm
        if (string.IsNullOrEmpty(utilizator))
        {
            CereNumeUtilizator(esteObligatoriu: true);
            ActualizeazaAfisareUtilizator();
            utilizator = ServiciuScoruri.UtilizatorCurent;
        }

        var fereastraQuiz = new QuizWindow(domeniu, utilizator);
        fereastraQuiz.Closed += (_, _) => Show();
        Hide();
        fereastraQuiz.Show();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CREARE / IMPORT DOMENII
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaCreeazaDomeniu(object sender, RoutedEventArgs e)
    {
        var fereastraCreare = new CreeazaDomeniuWindow { Owner = this };
        fereastraCreare.DomeniuCreat += domeniu =>
        {
            _domeniiPersonalizate.Add(domeniu);
            SalveazaDomeniiPersonalizate();
        };
        fereastraCreare.Closed += (_, _) => Show();
        Hide();
        fereastraCreare.Show();
    }

    private void LaIncarcareJson(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title  = "Selectează fișierul JSON",
            Filter = "JSON (*.json)|*.json|Toate fișierele (*.*)|*.*",
        };
        if (dialog.ShowDialog() != true) return;

        try
        {
            string json    = File.ReadAllText(dialog.FileName);
            var    optiuni = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var    domeniu = JsonSerializer.Deserialize<DomeniuQuiz>(json, optiuni);

            if (domeniu is null || domeniu.Intrebari.Count == 0)
            {
                MessageBox.Show("Fișierul nu conține întrebări valide.",
                    "Format invalid", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var raspuns = MessageBox.Show(
                $"Domeniu: {domeniu.Nume} ({domeniu.Intrebari.Count} întrebări)\n\n" +
                "Adaugi permanent în lista ta?",
                "Salvare permanentă?", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (raspuns == MessageBoxResult.Yes)
            {
                _domeniiPersonalizate.Add(domeniu);
                SalveazaDomeniiPersonalizate();
            }
            DeschideQuiz(domeniu);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Eroare:\n{ex.Message}", "Eroare", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void LaStergeDomeniu(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: DomeniuQuiz domeniu }) return;
        var conf = MessageBox.Show(
            $"Ștergi {domeniu.Nume} ?", "Confirmare",
            MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (conf != MessageBoxResult.Yes) return;
        _domeniiPersonalizate.Remove(domeniu);
        SalveazaDomeniiPersonalizate();
    }

    private void LaIesire(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

    private void SalveazaDomeniiPersonalizate()
        => ServiciuPersistenta.SalveazaDomenii(_domeniiPersonalizate);

    private void ActualizeazaVizibilitatePersonalizate()
        => bdSectiunePersonalizate.Visibility =
               _domeniiPersonalizate.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
}
