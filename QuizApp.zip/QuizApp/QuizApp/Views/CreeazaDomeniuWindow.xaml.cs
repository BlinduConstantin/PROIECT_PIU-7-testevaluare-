using System.Collections.ObjectModel;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using QuizApp.Models;
using QuizApp.ViewModels;
using System.IO;
namespace QuizApp.Views;

public partial class CreeazaDomeniuWindow : Window
{
    // Colecție observabilă → ItemsControl se actualizează automat la add/remove
    private readonly ObservableCollection<IntrebareEditabila> _intrebari = [];

    // Eveniment emis spre MainMenuWindow când utilizatorul salvează + pornește quiz
    public event Action<DomeniuQuiz>? DomeniuCreat;

    public CreeazaDomeniuWindow()
    {
        InitializeComponent();

        listIntrebari.ItemsSource = _intrebari;

        // La orice modificare a listei → actualizăm contorul și mesajul gol
        _intrebari.CollectionChanged += (_, _) => ActualizeazaUI();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CULOARE — previzualizare live
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaSchimareCuloare(object sender, TextChangedEventArgs e)
    {
        // previzualizareCuloare poate fi null dacă evenimentul se declanșează
        // în timpul inițializării XAML, înainte ca toate controalele să fie create
        if (previzualizareCuloare is null) return;

        try
        {
            var culoare = (Color)ColorConverter.ConvertFromString(tbCuloare.Text)!;
            previzualizareCuloare.Background = new SolidColorBrush(culoare);
        }
        catch
        {
            previzualizareCuloare.Background = new SolidColorBrush(Colors.Gray);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GESTIONARE ÎNTREBĂRI
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaAdaugareIntrebare(object sender, RoutedEventArgs e)
    {
        var intrebare = new IntrebareEditabila { NumarAfisare = _intrebari.Count + 1 };
        _intrebari.Add(intrebare);

        // Derulăm la final pentru a vedea noua întrebare
        Dispatcher.InvokeAsync(() =>
        {
            var scroll = FindScrollViewer();
            scroll?.ScrollToEnd();
        }, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private void LaEliminareIntrebare(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: IntrebareEditabila intrebare })
        {
            _intrebari.Remove(intrebare);
            // Renumerotăm
            for (int i = 0; i < _intrebari.Count; i++)
                _intrebari[i].NumarAfisare = i + 1;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SELECTARE IMAGINI
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaSelectarImagineIntrebare(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: IntrebareEditabila intrebare })
        {
            string? cale = SelecteazaFisierImagine();
            if (cale != null) intrebare.CaleImagine = cale;
        }
    }

    private void LaSelectarImagineRaspuns(object sender, RoutedEventArgs e)
    {
        // Tag-ul butonului este setat la obiectul RaspunsEditabil corespunzător
        if (sender is Button { Tag: RaspunsEditabil raspuns })
        {
            string? cale = SelecteazaFisierImagine();
            if (cale != null) raspuns.CaleImagine = cale;
        }
    }

    private static string? SelecteazaFisierImagine()
    {
        var dialog = new OpenFileDialog
        {
            Title  = "Selectează imaginea",
            Filter = "Imagini (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif" +
                     "|Toate fișierele (*.*)|*.*",
        };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // VALIDARE
    // ═══════════════════════════════════════════════════════════════════════════

    private bool Valideaza(out string mesajEroare)
    {
        if (string.IsNullOrWhiteSpace(tbNume.Text))
        {
            mesajEroare = "Completează numele domeniului.";
            tbNume.Focus();
            return false;
        }

        if (_intrebari.Count == 0)
        {
            mesajEroare = "Adaugă cel puțin o întrebare.";
            return false;
        }

        for (int i = 0; i < _intrebari.Count; i++)
        {
            var q = _intrebari[i];

            if (string.IsNullOrWhiteSpace(q.Text))
            {
                mesajEroare = $"Întrebarea {i + 1}: completează textul întrebării.";
                return false;
            }

            string[] texteRaspunsuri =
            [
                q.RaspunsA.Text, q.RaspunsB.Text,
                q.RaspunsC.Text, q.RaspunsD.Text
            ];

            for (int j = 0; j < 4; j++)
            {
                if (string.IsNullOrWhiteSpace(texteRaspunsuri[j]))
                {
                    mesajEroare = $"Întrebarea {i + 1}: completează varianta " +
                                  $"{(char)('A' + j)}.";
                    return false;
                }
            }
        }

        mesajEroare = "";
        return true;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONSTRUIRE MODEL
    // ═══════════════════════════════════════════════════════════════════════════

    private DomeniuQuiz ConstruiesteDomeniu() => new()
    {
        Nume       = tbNume.Text.Trim(),
        Pictograma = string.IsNullOrWhiteSpace(tbPictograma.Text) ? "❓" : tbPictograma.Text.Trim(),
        Descriere  = tbDescriere.Text.Trim(),
        CuloareHex = tbCuloare.Text.Trim(),
        Intrebari  = _intrebari.Select(i => i.ToModel()).ToList(),
    };

    // ═══════════════════════════════════════════════════════════════════════════
    // BUTOANE SUBSOL
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaPornireQuiz(object sender, RoutedEventArgs e)
    {
        if (!Valideaza(out string eroare))
        {
            tbEroareValidare.Text = "⚠  " + eroare;
            return;
        }

        tbEroareValidare.Text = "";
        var domeniu = ConstruiesteDomeniu();
        DomeniuCreat?.Invoke(domeniu);

        // Deschide direct quiz-ul cu domeniul creat
        var fereastraQuiz = new QuizWindow(domeniu);
        fereastraQuiz.Closed += (_, _) => Close();
        Hide();
        fereastraQuiz.Show();
    }

    private void LaSalvareJson(object sender, RoutedEventArgs e)
    {
        if (!Valideaza(out string eroare))
        {
            tbEroareValidare.Text = "⚠  " + eroare;
            return;
        }

        tbEroareValidare.Text = "";
        var domeniu = ConstruiesteDomeniu();

        var dialog = new SaveFileDialog
        {
            Title      = "Salvează domeniu ca JSON",
            Filter     = "JSON (*.json)|*.json",
            FileName   = $"{domeniu.Nume.Replace(" ", "_")}.json",
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            var optiuni = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(domeniu, optiuni);
            File.WriteAllText(dialog.FileName, json);

            // Informăm utilizatorul și oferim opțiunea de a porni quiz-ul
            var rezultat = MessageBox.Show(
                $"Domeniu salvat în:\n{dialog.FileName}\n\nVrei să pornești quiz-ul acum?",
                "Salvat cu succes", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (rezultat == MessageBoxResult.Yes)
            {
                DomeniuCreat?.Invoke(domeniu);
                var fereastraQuiz = new QuizWindow(domeniu);
                fereastraQuiz.Closed += (_, _) => Close();
                Hide();
                fereastraQuiz.Show();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Eroare la salvare:\n{ex.Message}",
                            "Eroare", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void LaAnulare(object sender, RoutedEventArgs e) => Close();

    // ═══════════════════════════════════════════════════════════════════════════
    // VALIDARE CÂMPURI NUMERICE (permite doar cifre)
    // ═══════════════════════════════════════════════════════════════════════════

    private void DoarNumere(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !e.Text.All(char.IsDigit);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // UTILITAR
    // ═══════════════════════════════════════════════════════════════════════════

    private void ActualizeazaUI()
    {
        int n = _intrebari.Count;
        tbNumarIntrebari.Text   = $"Întrebări ({n})";
        bdMesajGol.Visibility   = n == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private ScrollViewer? FindScrollViewer()
    {
        // Găsim ScrollViewer-ul din arborele vizual
        DependencyObject? el = listIntrebari;
        while (el != null)
        {
            if (el is ScrollViewer sv) return sv;
            el = VisualTreeHelper.GetParent(el);
        }
        return null;
    }
}
