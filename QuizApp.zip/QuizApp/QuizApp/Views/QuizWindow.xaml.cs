using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using QuizApp.Helpers;
using QuizApp.Models;
using QuizApp.ViewModels;

namespace QuizApp.Views;

public partial class QuizWindow : Window
{
    // ── Date quiz ─────────────────────────────────────────────────────────────
    private readonly DomeniuQuiz         _domeniu;
    private readonly List<Intrebare>     _intrebari;        // ordine aleatorie
    private readonly List<TentativaQuiz> _tentative = [];
    private int  _indexCurent = 0;
    private int  _scor        = 0;
    private int  _timpRamas;
    private bool _aRaspuns    = false;
    private readonly string  _utilizator;

    // Lista curentă de ViewModel-uri legate de ItemsControl
    private List<RaspunsAfisat> _raspunsuriCurente = [];

    // ── Cronometru (DispatcherTimer rulează pe firul UI) ──────────────────────
    private readonly DispatcherTimer _cronometru = new() { Interval = TimeSpan.FromSeconds(1) };

    // ─────────────────────────────────────────────────────────────────────────
    public QuizWindow(DomeniuQuiz domeniu, string utilizator = "")
    {
        InitializeComponent();

        _domeniu   = domeniu;
        _intrebari  = [.. domeniu.Intrebari.OrderBy(_ => Guid.NewGuid())];
        _utilizator = utilizator;
        _timpRamas = _intrebari.FirstOrDefault()?.LimitaTimp ?? 30;

        // Titlu fereastră
        Title = $"Quiz — {_domeniu.Nume}";

        // Expunem culoarea accent a domeniului ca resursă dinamică
        // → DataTemplate-ul din XAML o referențiază cu {DynamicResource PensulaAccentDomeniu}
        Resources["PensulaAccentDomeniu"] = _domeniu.PensulaAccent;

        // Culoare bară progres
        baraProgres.Foreground = _domeniu.PensulaAccent;

        // Culoare buton următor
        butonUrmator.Background = _domeniu.PensulaAccent;

        _cronometru.Tick += LaTickCronometru;
        Closed           += (_, _) => _cronometru.Stop();

        // Încărcăm prima întrebare după ce fereastra e afișată complet
        Loaded += (_, _) => IncarcaIntrebare(_indexCurent);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ÎNCĂRCARE ÎNTREBARE
    // ═══════════════════════════════════════════════════════════════════════════

    private void IncarcaIntrebare(int index)
    {
        if (index >= _intrebari.Count) { TerminaQuiz(); return; }

        var intrebare = _intrebari[index];

        _aRaspuns             = false;
        _timpRamas            = intrebare.LimitaTimp;
        butonUrmator.Visibility = Visibility.Collapsed;
        bdExplicatie.Visibility = Visibility.Collapsed;
        scrollContinut.ScrollToTop();

        // Antet
        tbInfo.Text  = $"{_domeniu.Pictograma}  {_domeniu.Nume}  ›  " +
                       $"Întrebarea {index + 1} din {_intrebari.Count}";
        tbScor.Text  = $"Scor: {_scor}";
        baraProgres.Maximum = _intrebari.Count;
        baraProgres.Value   = index;
        ActualizeazaCronometru();

        // Text întrebare
        tbIntrebare.Text = intrebare.Text;

        // Imagine întrebare
        if (intrebare.AreImagine)
        {
            var bitmap = IncarcatorImagini.Incarca(intrebare.CaleImagine);
            imgIntrebare.Source        = bitmap;
            bdImagineIntrebare.Visibility = Visibility.Visible;
        }
        else
        {
            bdImagineIntrebare.Visibility = Visibility.Collapsed;
            imgIntrebare.Source           = null;
        }

        // Construim lista de ViewModel-uri pentru răspunsuri
        string[] litere = ["A", "B", "C", "D"];
        _raspunsuriCurente = [];

        for (int i = 0; i < intrebare.Raspunsuri.Count && i < 4; i++)
        {
            var raspuns = intrebare.Raspunsuri[i];
            _raspunsuriCurente.Add(new RaspunsAfisat(_domeniu.PensulaAccent)
            {
                Indice      = i,
                Litera      = litere[i],
                Text        = raspuns.Text,
                CaleImagine = raspuns.CaleImagine,
            });
        }

        // Legăm ItemsControl-ul din XAML de lista de ViewModels
        listRaspunsuri.ItemsSource = _raspunsuriCurente;

        _cronometru.Start();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CLICK PE RĂSPUNS  — evenimentul e definit în DataTemplate-ul XAML
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaClickRaspuns(object sender, RoutedEventArgs e)
    {
        if (_aRaspuns) return;
        if (sender is Button { Tag: int indice })
            SelecteazaRaspuns(indice);
    }

    private void SelecteazaRaspuns(int indexAles)
    {
        _aRaspuns = true;
        _cronometru.Stop();

        var intrebare   = _intrebari[_indexCurent];
        bool esteCorect = indexAles == intrebare.IndiceRaspunsCorect;
        if (esteCorect) _scor += intrebare.Puncte;
        tbScor.Text = $"Scor: {_scor}";

        _tentative.Add(new TentativaQuiz { Intrebare = intrebare, RaspunsUtilizator = indexAles });

        // Actualizăm culorile prin proprietățile INPC ale fiecărui ViewModel
        ColoreazaRaspunsuri(intrebare.IndiceRaspunsCorect, indexAles);
        AfiseazaExplicatie(intrebare, esteCorect ? "✅" : "❌");

        butonUrmator.Content    = _indexCurent < _intrebari.Count - 1
                                  ? "Următoarea  ▶" : "🏆  Rezultate";
        butonUrmator.Visibility = Visibility.Visible;
    }

    // ── Colorare carduri după selecție ────────────────────────────────────────

    private void ColoreazaRaspunsuri(int indiceCorect, int indiceAles)
    {
        // Verde = corect, Roșu = ales greșit, Estompat = restul
        var pensulaSucces   = new SolidColorBrush(Color.FromRgb(15, 60, 30));
        var textSucces      = new SolidColorBrush(Color.FromRgb(100, 230, 130));
        var pensulaGresit   = new SolidColorBrush(Color.FromRgb(60, 15, 12));
        var textGresit      = new SolidColorBrush(Color.FromRgb(240, 120, 120));
        var textEstompat    = new SolidColorBrush(Color.FromRgb(90, 90, 120));

        foreach (var vm in _raspunsuriCurente)
        {
            vm.EsteActiv = false;   // dezactivează hover + click

            if (vm.Indice == indiceCorect)
            {
                vm.Fundal        = pensulaSucces;
                vm.CuloareText   = textSucces;
                vm.CuloareLitera = textSucces;
            }
            else if (vm.Indice == indiceAles)
            {
                vm.Fundal        = pensulaGresit;
                vm.CuloareText   = textGresit;
                vm.CuloareLitera = textGresit;
            }
            else
            {
                vm.CuloareText   = textEstompat;
                vm.CuloareLitera = textEstompat;
            }
        }
    }

    private void AfiseazaExplicatie(Intrebare intrebare, string pictograma)
    {
        string text = string.IsNullOrWhiteSpace(intrebare.Explicatie)
            ? $"{pictograma}  Răspuns corect: " +
              $"{intrebare.Raspunsuri[intrebare.IndiceRaspunsCorect].Text}"
            : $"{pictograma}  {intrebare.Explicatie}";

        tbExplicatie.Text       = text;
        bdExplicatie.Visibility = Visibility.Visible;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CRONOMETRU
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaTickCronometru(object? sender, EventArgs e)
    {
        _timpRamas--;
        ActualizeazaCronometru();
        if (_timpRamas > 0) return;

        _cronometru.Stop();
        _aRaspuns = true;

        var intrebare = _intrebari[_indexCurent];
        _tentative.Add(new TentativaQuiz { Intrebare = intrebare, RaspunsUtilizator = -1 });

        // Evidențiem răspunsul corect; restul estompate
        ColoreazaRaspunsuri(intrebare.IndiceRaspunsCorect, indiceAles: -99);
        AfiseazaExplicatie(intrebare, "⏰");

        butonUrmator.Content    = _indexCurent < _intrebari.Count - 1
                                  ? "Următoarea  ▶" : "🏆  Rezultate";
        butonUrmator.Visibility = Visibility.Visible;
    }

    private void ActualizeazaCronometru()
    {
        tbCronometru.Text       = $"⏱ {_timpRamas}";
        tbCronometru.Foreground = _timpRamas > 15
            ? (Brush)FindResource("PensulaCronSigur")
            : _timpRamas > 7
                ? (Brush)FindResource("PensulaCronAvertism")
                : (Brush)FindResource("PensulaCronPericol");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NAVIGARE
    // ═══════════════════════════════════════════════════════════════════════════

    private void LaUrmator(object sender, RoutedEventArgs e)
    {
        _indexCurent++;
        IncarcaIntrebare(_indexCurent);
    }

    private void TerminaQuiz()
    {
        var fereastraRezultate = new ResultsWindow(_domeniu, _tentative, _scor, _utilizator);
        fereastraRezultate.Closed += (_, _) => Close();
        Hide();
        fereastraRezultate.Show();
    }
}
