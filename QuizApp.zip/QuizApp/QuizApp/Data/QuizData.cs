using QuizApp.Models;

namespace QuizApp.Data;

/// <summary>
/// Banca de întrebări încorporată.
/// Întrebările cu <c>CaleImagine</c> setată așteaptă fișierele corespunzătoare
/// în folderul <c>Images\</c> de lângă executabil, sau orice URL HTTP/HTTPS.
///
/// Pentru a adăuga un domeniu propriu, selectați „Încarcă din JSON" din meniu
/// și alegeți un fișier JSON care respectă schema DomeniuQuiz
/// (vezi Resources\exemplu_domeniu.json).
/// </summary>
public static class DateQuiz
{
    public static List<DomeniuQuiz> ObtineDoменiiIncorporate() =>
    [
        Geografie(),
        Istorie(),
        Stiinta(),
        Informatica(),
        CulturaGenerala(),
    ];

    // ═══════════════════════════════════════════════════════════════════════
    // 🌍 GEOGRAFIE
    // ═══════════════════════════════════════════════════════════════════════
    private static DomeniuQuiz Geografie() => new()
    {
        Nume       = "Geografie",
        Pictograma = "🌍",
        Descriere  = "Lacuri, munți, capitale, relief și fenomene naturale",
        CuloareHex = "#2E8B57",
        Intrebari  =
        [
            // ── Întrebare cu IMAGINE în întrebare ─────────────────────────
            new()
            {
                Text        = "Ce lac apare în imaginea următoare?\n(Adaugă Images\\lacul_baikal.jpg pentru a vedea fotografia)",
                CaleImagine = @"Images\lacul_baikal.jpg",
                Raspunsuri  =
                [
                    new() { Text = "Lacul Victoria (Africa)"  },
                    new() { Text = "Lacul Baikal (Rusia)"     },
                    new() { Text = "Marea Caspică (Asia)"     },
                    new() { Text = "Lacul Superior (America)" },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Lacul Baikal din Siberia este cel mai adânc lac din lume (1.642 m) și conține ~20% din apa dulce de suprafață a planetei.",
                Puncte     = 15,
            },

            // ── Întrebare cu IMAGINI în răspunsuri (steaguri) ─────────────
            new()
            {
                Text       = "Care dintre aceste steaguri aparține României?\n(Adaugă Images\\steag_*.png pentru a vedea steagurile)",
                Raspunsuri =
                [
                    new() { Text = "Franța",   CaleImagine = @"Images\steag_franta.png"   },
                    new() { Text = "Germania", CaleImagine = @"Images\steag_germania.png" },
                    new() { Text = "România",  CaleImagine = @"Images\steag_romania.png"  },
                    new() { Text = "Italia",   CaleImagine = @"Images\steag_italia.png"   },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Drapelul României are trei benzi verticale egale: albastru (cobalt), galben și roșu.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Care este cel mai mare deșert din lume?",
                Raspunsuri =
                [
                    new() { Text = "Sahara (Africa de Nord)"     },
                    new() { Text = "Gobi (Asia Centrală)"        },
                    new() { Text = "Antarctica"                  },
                    new() { Text = "Arabian (Peninsula Arabică)" },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Antarctica (~14,2 mil km²) este cel mai mare deșert din lume. Un deșert se definește prin precipitații reduse (<250 mm/an), nu prin temperaturi ridicate!",
                Puncte     = 15,
            },

            new()
            {
                Text       = "Care este capitala Australiei?",
                Raspunsuri =
                [
                    new() { Text = "Sydney"    },
                    new() { Text = "Melbourne" },
                    new() { Text = "Canberra"  },
                    new() { Text = "Brisbane"  },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Canberra a fost construită special ca capitală federală ca un compromis între Sydney și Melbourne, cele mai mari două orașe rivale.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Care este cel mai lung râu din lume?",
                Raspunsuri =
                [
                    new() { Text = "Amazonul (America de Sud)" },
                    new() { Text = "Nilul (Africa)"            },
                    new() { Text = "Yangtzele (China)"         },
                    new() { Text = "Mississippi (SUA)"         },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Nilul (~6.650 km) este considerat cel mai lung râu din lume, deși un studiu din 2007 susține că Amazonul ar fi mai lung (~6.800 km).",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Delta Dunării se varsă în:",
                Raspunsuri =
                [
                    new() { Text = "Marea Mediterană" },
                    new() { Text = "Marea Neagră"     },
                    new() { Text = "Marea Caspică"    },
                    new() { Text = "Marea Azov"       },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Dunărea se varsă în Marea Neagră prin trei brațe: Chilia, Sulina și Sfântul Gheorghe. Delta Dunării este cel mai mare delta bine conservat din Europa.",
                Puncte          = 10,
                LimitaTimp      = 25,
            },
        ]
    };

    // ═══════════════════════════════════════════════════════════════════════
    // 🏛️ ISTORIE
    // ═══════════════════════════════════════════════════════════════════════
    private static DomeniuQuiz Istorie() => new()
    {
        Nume       = "Istorie",
        Pictograma = "🏛️",
        Descriere  = "Evenimente, personalități și epoci din istoria universală și românească",
        CuloareHex = "#8B4513",
        Intrebari  =
        [
            new()
            {
                Text        = "Ce monument apare în imaginea alăturată?\n(Adaugă Images\\colosseum.jpg)",
                CaleImagine = @"Images\colosseum.jpg",
                Raspunsuri  =
                [
                    new() { Text = "Pantheonul din Roma"  },
                    new() { Text = "Colosseumul din Roma" },
                    new() { Text = "Forumul Roman"        },
                    new() { Text = "Circus Maximus"       },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Colosseumul (Amphitheatrum Flavium), construit între 70–80 d.Hr., putea găzdui 50.000–80.000 de spectatori la luptele de gladiatori.",
                Puncte     = 15,
            },

            new()
            {
                Text       = "În ce an a căzut Constantinopolul în mâinile otomanilor?",
                Raspunsuri =
                [
                    new() { Text = "1389" },
                    new() { Text = "1453" },
                    new() { Text = "1492" },
                    new() { Text = "1529" },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Constantinopolul a căzut pe 29 mai 1453, sultanul Mehmed al II-lea cucerind orașul și punând capăt Imperiului Bizantin de 1.000 de ani.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Cine a realizat Unirea Principatelor Române în 1859?",
                Raspunsuri =
                [
                    new() { Text = "Mihail Kogălniceanu" },
                    new() { Text = "Alexandru Ioan Cuza" },
                    new() { Text = "Carol I"             },
                    new() { Text = "Mihai Viteazul"      },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Alexandru Ioan Cuza a fost ales domn al Moldovei (5 ian.) și al Țării Românești (24 ian. 1859). Dubla alegere a realizat unirea de facto.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Revoluția Franceză a început în anul:",
                Raspunsuri =
                [
                    new() { Text = "1776" },
                    new() { Text = "1789" },
                    new() { Text = "1804" },
                    new() { Text = "1815" },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Revoluția Franceză a început cu luarea Bastiliei pe 14 iulie 1789, dată celebrată și azi ca Ziua Națională a Franței.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Marea Unire a României s-a realizat în anul:",
                Raspunsuri =
                [
                    new() { Text = "1859" },
                    new() { Text = "1877" },
                    new() { Text = "1918" },
                    new() { Text = "1921" },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Pe 1 decembrie 1918 s-a votat la Alba Iulia unirea Transilvaniei cu România. Această dată este azi Ziua Națională a României.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Al Doilea Război Mondial s-a încheiat în Europa în:",
                Raspunsuri =
                [
                    new() { Text = "8 mai 1944"         },
                    new() { Text = "8 mai 1945"         },
                    new() { Text = "2 septembrie 1945"  },
                    new() { Text = "6 iunie 1944"       },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Germania a capitulat necondiționat pe 8 mai 1945 (VE Day). Războiul în Pacific a continuat până pe 2 septembrie 1945.",
                Puncte     = 10,
            },
        ]
    };

    // ═══════════════════════════════════════════════════════════════════════
    // 🔬 ȘTIINȚĂ
    // ═══════════════════════════════════════════════════════════════════════
    private static DomeniuQuiz Stiinta() => new()
    {
        Nume       = "Știință",
        Pictograma = "🔬",
        Descriere  = "Fizică, chimie, biologie și astronomie",
        CuloareHex = "#1E6FA8",
        Intrebari  =
        [
            new()
            {
                Text        = "Ce structură apare în imaginea de mai jos?\n(Adaugă Images\\dublu_helix.jpg)",
                CaleImagine = @"Images\dublu_helix.jpg",
                Raspunsuri  =
                [
                    new() { Text = "Un lanț proteic (polipeptidic)" },
                    new() { Text = "ADN dublu helix"                },
                    new() { Text = "ARN mesager"                    },
                    new() { Text = "Cromozom condensat"             },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Structura dublului helix a ADN-ului a fost descoperită în 1953 de Watson și Crick, pe baza datelor de difracție X obținute de Rosalind Franklin.",
                Puncte     = 15,
            },

            new()
            {
                Text       = "Care este viteza luminii în vid?",
                Raspunsuri =
                [
                    new() { Text = "≈ 300.000 km/s"  },
                    new() { Text = "≈ 30.000 km/s"   },
                    new() { Text = "≈ 150.000 km/s"  },
                    new() { Text = "≈ 3.000.000 km/s"},
                ],
                IndiceRaspunsCorect = 0,
                Explicatie = "Viteza luminii în vid este c ≈ 299.792.458 m/s (~300.000 km/s). Conform relativității speciale, nicio masă nu poate atinge această viteză.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Care este simbolul chimic al aurului?",
                Raspunsuri =
                [
                    new() { Text = "Ag (Argentum)" },
                    new() { Text = "Au (Aurum)"    },
                    new() { Text = "Fe (Ferrum)"   },
                    new() { Text = "Cu (Cuprum)"   },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Au vine din latinescul Aurum. Ag = Argint, Fe = Fier, Cu = Cupru — toate simbolurile provin din denumirile latinești.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Câți cromozomi are o celulă somatică umană normală?",
                Raspunsuri =
                [
                    new() { Text = "23 (haploid)" },
                    new() { Text = "46 (diploid)" },
                    new() { Text = "48"           },
                    new() { Text = "64"           },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Celulele somatice (de corp) au 46 de cromozomi în 23 de perechi. Gameții (ovul, spermatozoid) au 23 (haploid).",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Tabelul periodic a fost creat de:",
                Raspunsuri =
                [
                    new() { Text = "Antoine Lavoisier" },
                    new() { Text = "John Dalton"       },
                    new() { Text = "Dmitri Mendeleev"  },
                    new() { Text = "Marie Curie"       },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Dmitri Mendeleev (1869) a aranjat elementele după masa atomică și a prezis elementele nedescoperite încă, lăsând goluri în tabel.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Planeta cea mai apropiată de Soare este:",
                Raspunsuri =
                [
                    new() { Text = "Venus"    },
                    new() { Text = "Marte"    },
                    new() { Text = "Mercur"   },
                    new() { Text = "Pământul" },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Mercur este prima planetă a Sistemului Solar (dist. medie ~57,9 mil km față de Soare).",
                Puncte     = 10,
            },
        ]
    };

    // ═══════════════════════════════════════════════════════════════════════
    // 💻 INFORMATICĂ
    // ═══════════════════════════════════════════════════════════════════════
    private static DomeniuQuiz Informatica() => new()
    {
        Nume       = "Informatică",
        Pictograma = "💻",
        Descriere  = "Algoritmi, rețele, baze de date și programare",
        CuloareHex = "#6A0DAD",
        Intrebari  =
        [
            new()
            {
                Text        = "Ce structură de date apare în imaginea de mai jos?\n(Adaugă Images\\arbore_binar.png)",
                CaleImagine = @"Images\arbore_binar.png",
                Raspunsuri  =
                [
                    new() { Text = "Graf orientat"          },
                    new() { Text = "Arbore binar de căutare"},
                    new() { Text = "Tabel hash"             },
                    new() { Text = "Listă înlănțuită"       },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Un arbore binar de căutare (BST) are proprietatea că subarborele stâng conține valori mai mici, iar cel drept valori mai mari decât nodul curent.",
                Puncte     = 15,
            },

            new()
            {
                Text       = "Care este complexitatea temporală a sortării rapide (QuickSort) în cazul mediu?",
                Raspunsuri =
                [
                    new() { Text = "O(n)"       },
                    new() { Text = "O(n log n)" },
                    new() { Text = "O(n²)"      },
                    new() { Text = "O(log n)"   },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "QuickSort are complexitate medie O(n log n) și O(n²) în cel mai nefavorabil caz. În practică este deseori mai rapid decât MergeSort.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Ce înseamnă acronimul SQL?",
                Raspunsuri =
                [
                    new() { Text = "Structured Query Language"  },
                    new() { Text = "Simple Question Language"   },
                    new() { Text = "Sequential Query Logic"     },
                    new() { Text = "Standard Question Library"  },
                ],
                IndiceRaspunsCorect = 0,
                Explicatie = "SQL (Structured Query Language) este limbajul standard pentru gestiunea bazelor de date relaționale, creat în anii '70 la IBM.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Care protocol se folosește pentru navigarea securizată pe web?",
                Raspunsuri =
                [
                    new() { Text = "FTP"   },
                    new() { Text = "HTTP"  },
                    new() { Text = "HTTPS" },
                    new() { Text = "SMTP"  },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "HTTPS (HTTP Secure) folosește TLS/SSL pentru criptarea traficului dintre browser și server, protejând datele transmise.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Câți biți are un octet (byte)?",
                Raspunsuri =
                [
                    new() { Text = "4"  },
                    new() { Text = "8"  },
                    new() { Text = "16" },
                    new() { Text = "32" },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "Un byte = 8 biți. Această convenție universală a fost adoptată de IBM la sfârșitul anilor '60. Un nibble = 4 biți.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Care dintre următoarele este un limbaj de programare orientat pe obiecte?",
                Raspunsuri =
                [
                    new() { Text = "Assembly" },
                    new() { Text = "C"        },
                    new() { Text = "Prolog"   },
                    new() { Text = "C#"       },
                ],
                IndiceRaspunsCorect = 3,
                Explicatie = "C# este un limbaj OOP creat de Microsoft (Anders Hejlsberg, 2000), rulând pe .NET. Assembly și C sunt procedurale; Prolog este logic-declarativ.",
                Puncte     = 10,
            },
        ]
    };

    // ═══════════════════════════════════════════════════════════════════════
    // 📚 CULTURĂ GENERALĂ
    // ═══════════════════════════════════════════════════════════════════════
    private static DomeniuQuiz CulturaGenerala() => new()
    {
        Nume       = "Cultură Generală",
        Pictograma = "📚",
        Descriere  = "Artă, literatură, muzică și personalități celebre",
        CuloareHex = "#8B008B",
        Intrebari  =
        [
            new()
            {
                Text        = "Cine a realizat tabloul din imaginea alăturată?\n(Adaugă Images\\mona_lisa.jpg)",
                CaleImagine = @"Images\mona_lisa.jpg",
                Raspunsuri  =
                [
                    new() { Text = "Michelangelo Buonarroti" },
                    new() { Text = "Raphael Sanzio"          },
                    new() { Text = "Leonardo da Vinci"       },
                    new() { Text = "Sandro Botticelli"       },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Mona Lisa (1503–1519) de Leonardo da Vinci este expusă la Luvru și considerată cea mai valoroasă pictură din lume.",
                Puncte     = 15,
            },

            new()
            {
                Text       = "Cine a scris romanul Ion (1920)?",
                Raspunsuri =
                [
                    new() { Text = "Mihail Sadoveanu" },
                    new() { Text = "Liviu Rebreanu"   },
                    new() { Text = "George Călinescu" },
                    new() { Text = "Ion Creangă"      },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "'Ion' de Liviu Rebreanu (1920) este primul roman realist modern din literatura română, tratând tema pământului și a condiției țăranului ardelean.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Câte simfonii a compus Ludwig van Beethoven?",
                Raspunsuri =
                [
                    new() { Text = "7"  },
                    new() { Text = "8"  },
                    new() { Text = "9"  },
                    new() { Text = "10" },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Beethoven a compus 9 simfonii. Simfonia nr. 9 (cu 'Oda Bucuriei') a fost compusă când era complet surd.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Opera Nabucco a fost compusă de:",
                Raspunsuri =
                [
                    new() { Text = "Wolfgang Amadeus Mozart" },
                    new() { Text = "Giuseppe Verdi"          },
                    new() { Text = "Giacomo Puccini"         },
                    new() { Text = "Gioachino Rossini"       },
                ],
                IndiceRaspunsCorect = 1,
                Explicatie = "'Nabucco' (1842) l-a consacrat pe Giuseppe Verdi. Corul 'Va, pensiero' a devenit un simbol al unificării Italiei.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Premiul Nobel pentru Fizică din 1921 i-a revenit lui:",
                Raspunsuri =
                [
                    new() { Text = "Niels Bohr"       },
                    new() { Text = "Max Planck"        },
                    new() { Text = "Albert Einstein"   },
                    new() { Text = "Werner Heisenberg" },
                ],
                IndiceRaspunsCorect = 2,
                Explicatie = "Einstein a primit Nobelul pentru Fizică în 1921 nu pentru relativitate, ci pentru explicarea efectului fotoelectric.",
                Puncte     = 10,
            },

            new()
            {
                Text       = "Cine a scris poemul Luceafărul?",
                Raspunsuri =
                [
                    new() { Text = "George Coșbuc"   },
                    new() { Text = "Vasile Alecsandri"},
                    new() { Text = "Ion Barbu"        },
                    new() { Text = "Mihai Eminescu"   },
                ],
                IndiceRaspunsCorect = 3,
                Explicatie = "'Luceafărul' (1883) de Mihai Eminescu este capodopera poeziei romantice românești, publicată în Almanahul Societății Academice Social-Literare.",
                Puncte     = 10,
            },
        ]
    };
}
