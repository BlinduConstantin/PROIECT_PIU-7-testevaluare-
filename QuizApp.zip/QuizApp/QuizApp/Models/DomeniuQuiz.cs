using System.Text.Json.Serialization;
using System.Windows.Media;

namespace QuizApp.Models;

public class DomeniuQuiz
{
    public string Nume        { get; set; } = string.Empty;
    public string Pictograma  { get; set; } = "❓";
    public string Descriere   { get; set; } = string.Empty;
    public string CuloareHex  { get; set; } = "#4682B4";
    public List<Intrebare> Intrebari { get; set; } = new();

    [JsonIgnore]
    public int TotalPuncte => Intrebari.Sum(i => i.Puncte);

    [JsonIgnore]
    public Color CuloareAccent
    {
        get
        {
            try   { return (Color)ColorConverter.ConvertFromString(CuloareHex)!; }
            catch { return Colors.SteelBlue; }
        }
    }

    [JsonIgnore]
    public SolidColorBrush PensulaAccent => new(CuloareAccent);
}
