using System.Text.Json.Serialization;

namespace QuizApp.Models;

public class Intrebare
{
    public string        Text                { get; set; } = string.Empty;
    public string?       CaleImagine         { get; set; }
    public List<Raspuns> Raspunsuri          { get; set; } = new();
    public int           IndiceRaspunsCorect { get; set; }
    public string?       Explicatie          { get; set; }
    public int           Puncte              { get; set; } = 10;
    public int           LimitaTimp          { get; set; } = 30;

    [JsonIgnore]
    public bool AreImagine => !string.IsNullOrWhiteSpace(CaleImagine);
}
