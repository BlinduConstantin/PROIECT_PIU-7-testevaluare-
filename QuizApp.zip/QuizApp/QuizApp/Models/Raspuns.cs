using System.Text.Json.Serialization;

namespace QuizApp.Models;

public class Raspuns
{
    public string  Text        { get; set; } = string.Empty;
    public string? CaleImagine { get; set; }

    [JsonIgnore]
    public bool AreImagine => !string.IsNullOrWhiteSpace(CaleImagine);
}
