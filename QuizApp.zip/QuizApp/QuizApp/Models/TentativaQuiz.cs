namespace QuizApp.Models;

public class TentativaQuiz
{
    public Intrebare Intrebare         { get; init; } = null!;
    public int       RaspunsUtilizator { get; init; }   // -1 = timp expirat

    public bool EsteCorect     => RaspunsUtilizator == Intrebare.IndiceRaspunsCorect;
    public bool AExpirat       => RaspunsUtilizator == -1;
    public int  PuncteObtinute => EsteCorect ? Intrebare.Puncte : 0;
}
