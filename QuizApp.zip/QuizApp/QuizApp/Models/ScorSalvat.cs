using System.Text.Json.Serialization;

namespace QuizApp.Models;

/// <summary>Înregistrarea unui scor obținut de un utilizator la un quiz.</summary>
public class ScorSalvat
{
    public string   Utilizator       { get; set; } = "";
    public string   NumeDomeniu      { get; set; } = "";
    public string   PictogramaDomeniu{ get; set; } = "❓";
    public int      Scor             { get; set; }
    public int      ScorMaxim        { get; set; }
    public int      NrCorecte        { get; set; }
    public int      TotalIntrebari   { get; set; }
    public DateTime DataOra          { get; set; } = DateTime.Now;

    [JsonIgnore]
    public double Procent =>
        ScorMaxim > 0 ? Math.Round(100.0 * Scor / ScorMaxim, 1) : 0;

    [JsonIgnore]
    public string DataOraFormatata => DataOra.ToString("dd.MM.yyyy  HH:mm");

    [JsonIgnore]
    public string ScorFormatat => $"{Scor} / {ScorMaxim}";
}
