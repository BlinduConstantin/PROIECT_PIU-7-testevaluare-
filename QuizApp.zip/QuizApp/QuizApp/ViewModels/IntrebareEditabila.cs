using System.ComponentModel;
using System.Runtime.CompilerServices;
using QuizApp.Models;

namespace QuizApp.ViewModels;

/// <summary>
/// ViewModel editabil pentru o întrebare quiz.
/// Expune cele patru răspunsuri ca proprietăți individuale (RaspunsA–D)
/// pentru binding direct în XAML fără ItemsControl imbricat.
/// </summary>
public class IntrebareEditabila : INotifyPropertyChanged
{
    // ── Câmpuri ───────────────────────────────────────────────────────────────
    private int    _numarAfisare        = 1;
    private string _text                = "";
    private string _caleImagine         = "";
    private string _explicatie          = "";
    private int    _puncte              = 10;
    private int    _limitaTimp          = 30;
    private int    _indiceRaspunsCorect = 0;

    // ── Proprietăți ───────────────────────────────────────────────────────────
    public int NumarAfisare
    {
        get => _numarAfisare;
        set { _numarAfisare = value; N(); N(nameof(Titlu)); }
    }

    public string Titlu => $"Întrebarea {_numarAfisare}";

    public string Text
    {
        get => _text;
        set { _text = value; N(); }
    }

    public string CaleImagine
    {
        get => _caleImagine;
        set { _caleImagine = value; N(); }
    }

    public string Explicatie
    {
        get => _explicatie;
        set { _explicatie = value; N(); }
    }

    public int Puncte
    {
        get => _puncte;
        set { _puncte = Math.Max(1, value); N(); }
    }

    public int LimitaTimp
    {
        get => _limitaTimp;
        set { _limitaTimp = Math.Max(5, value); N(); }
    }

    public int IndiceRaspunsCorect
    {
        get => _indiceRaspunsCorect;
        set { _indiceRaspunsCorect = value; N(); }
    }

    // ── Cele patru răspunsuri (expuse individual pentru binding simplu) ────────
    public RaspunsEditabil RaspunsA { get; } = new();
    public RaspunsEditabil RaspunsB { get; } = new();
    public RaspunsEditabil RaspunsC { get; } = new();
    public RaspunsEditabil RaspunsD { get; } = new();

    // ── Conversie → model de date ─────────────────────────────────────────────
    public Intrebare ToModel() => new()
    {
        Text                = Text.Trim(),
        CaleImagine         = string.IsNullOrWhiteSpace(CaleImagine) ? null : CaleImagine.Trim(),
        IndiceRaspunsCorect = IndiceRaspunsCorect,
        Explicatie          = string.IsNullOrWhiteSpace(Explicatie)  ? null : Explicatie.Trim(),
        Puncte              = Puncte,
        LimitaTimp          = LimitaTimp,
        Raspunsuri          =
        [
            RaspunsToModel(RaspunsA),
            RaspunsToModel(RaspunsB),
            RaspunsToModel(RaspunsC),
            RaspunsToModel(RaspunsD),
        ],
    };

    private static Raspuns RaspunsToModel(RaspunsEditabil r) => new()
    {
        Text        = r.Text.Trim(),
        CaleImagine = string.IsNullOrWhiteSpace(r.CaleImagine) ? null : r.CaleImagine.Trim(),
    };

    // ── INotifyPropertyChanged ────────────────────────────────────────────────
    public event PropertyChangedEventHandler? PropertyChanged;
    private void N([CallerMemberName] string? p = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
}
