using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace QuizApp.ViewModels;

/// <summary>ViewModel editabil pentru o variantă de răspuns (TextBox-uri legate TwoWay).</summary>
public class RaspunsEditabil : INotifyPropertyChanged
{
    private string _text        = "";
    private string _caleImagine = "";

    public string Text
    {
        get => _text;
        set { _text = value; N(); }
    }

    public string CaleImagine
    {
        get => _caleImagine;
        set { _caleImagine = value; N(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void N([CallerMemberName] string? p = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(p));
}
