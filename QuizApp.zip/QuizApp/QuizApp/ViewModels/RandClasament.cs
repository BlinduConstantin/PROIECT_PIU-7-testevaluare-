using System.Windows.Media;
using QuizApp.Models;

namespace QuizApp.ViewModels;

/// <summary>ViewModel pentru un rând din tabelul ClasamentWindow.</summary>
public class RandClasament
{
    public ScorSalvat Scor              { get; init; } = null!;
    public int        Loc               { get; init; }
    public bool       EsteUtilizatorCurent { get; init; }

    // ── Simbol și culori bazate pe loc ──────────────────────────────────────
    public string SimbolLoc => Loc switch
    {
        1 => "🥇",
        2 => "🥈",
        3 => "🥉",
        _ => Loc.ToString(),
    };

    public SolidColorBrush CuloareLoc => Loc switch
    {
        1 => new SolidColorBrush(Color.FromRgb(255, 215,   0)),  // aur
        2 => new SolidColorBrush(Color.FromRgb(192, 192, 192)),  // argint
        3 => new SolidColorBrush(Color.FromRgb(205, 127,  50)),  // bronz
        _ => new SolidColorBrush(Color.FromRgb(150, 150, 185)),  // normal
    };

    public SolidColorBrush CuloareUtilizator =>
        EsteUtilizatorCurent
            ? new SolidColorBrush(Color.FromRgb(100, 210, 140))
            : new SolidColorBrush(Color.FromRgb(235, 235, 245));

    public SolidColorBrush CuloareProcent => Scor.Procent switch
    {
        >= 90 => new SolidColorBrush(Color.FromRgb( 39, 174,  96)),
        >= 75 => new SolidColorBrush(Color.FromRgb(220, 200,  60)),
        >= 55 => new SolidColorBrush(Color.FromRgb(210, 150,  80)),
        _     => new SolidColorBrush(Color.FromRgb(192,  57,  43)),
    };

    public SolidColorBrush FundalRand =>
        EsteUtilizatorCurent
            ? new SolidColorBrush(Color.FromRgb(20, 45, 30))
            : new SolidColorBrush(Color.FromRgb(28, 28, 44));

    public SolidColorBrush MargineRand =>
        new SolidColorBrush(Color.FromRgb(38, 38, 60));
}
