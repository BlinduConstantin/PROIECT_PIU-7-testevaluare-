using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using QuizApp.Helpers;

namespace QuizApp.ViewModels;

public class RaspunsAfisat : INotifyPropertyChanged
{
    public int     Indice      { get; init; }
    public string  Litera      { get; init; } = "";
    public string  Text        { get; init; } = "";
    public string? CaleImagine { get; init; }
    public bool    AreImagine  => !string.IsNullOrWhiteSpace(CaleImagine);

    private BitmapImage? _imagine;
    public BitmapImage? ImagineRaspuns
    {
        get { if (_imagine == null && AreImagine) _imagine = IncarcatorImagini.Incarca(CaleImagine); return _imagine; }
    }

    private SolidColorBrush _fundal       = new(Color.FromRgb(38, 38, 60));
    private SolidColorBrush _culoareText  = new(Color.FromRgb(235, 235, 245));
    private SolidColorBrush _culoareLitera;
    private bool             _esteActiv   = true;

    public SolidColorBrush Fundal        { get => _fundal;        set { _fundal = value;        N(); } }
    public SolidColorBrush CuloareText   { get => _culoareText;   set { _culoareText = value;   N(); } }
    public SolidColorBrush CuloareLitera { get => _culoareLitera; set { _culoareLitera = value; N(); } }
    public bool EsteActiv                { get => _esteActiv;     set { _esteActiv = value;     N(); } }

    public RaspunsAfisat(SolidColorBrush pensulaAccent) { _culoareLitera = pensulaAccent; }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void N([CallerMemberName] string? p = null) => PropertyChanged?.Invoke(this, new(p));
}
