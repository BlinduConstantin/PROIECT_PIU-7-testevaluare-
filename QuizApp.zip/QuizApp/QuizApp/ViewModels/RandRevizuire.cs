using System.Windows.Media;

namespace QuizApp.ViewModels;

/// <summary>ViewModel pentru un rând din lista de revizuire a ResultsWindow.</summary>
public class RandRevizuire
{
    public string          Pictograma     { get; init; } = "";
    public string          TextIntrebare  { get; init; } = "";
    public string          TextRaspuns    { get; init; } = "";
    public string          TextPuncte     { get; init; } = "";
    public SolidColorBrush Fundal         { get; init; } = new(Color.FromRgb(20, 20, 33));
    public SolidColorBrush CuloareDunga   { get; init; } = new(Colors.Gray);
    public SolidColorBrush CuloareRaspuns { get; init; } = new(Colors.LightGray);
    public SolidColorBrush CuloarePuncte  { get; init; } = new(Colors.Gray);
}
