using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace QuizApp.Helpers;

/// <summary>Convertește un string hex (#RRGGBB) în SolidColorBrush.</summary>
[ValueConversion(typeof(string), typeof(SolidColorBrush))]
public class ConvertorCuloare : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is string hex && !string.IsNullOrWhiteSpace(hex))
        {
            try
            {
                var culoare = (Color)ColorConverter.ConvertFromString(hex)!;
                return new SolidColorBrush(culoare);
            }
            catch { }
        }
        return new SolidColorBrush(Colors.SteelBlue);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>Returnează Collapsed când valoarea bool este True.</summary>
[ValueConversion(typeof(bool), typeof(System.Windows.Visibility))]
public class ConvertorInversViz : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => value is true ? System.Windows.Visibility.Collapsed : System.Windows.Visibility.Visible;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
