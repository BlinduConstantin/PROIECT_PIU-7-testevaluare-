using System.Windows.Media.Imaging;
using System.IO;
namespace QuizApp.Helpers;

/// <summary>
/// Creează BitmapImage pentru WPF din căi locale sau URL-uri HTTP(S).
/// WPF gestionează automat descărcarea asincronă pentru URL-uri HTTP.
/// </summary>
public static class IncarcatorImagini
{
    private static readonly Dictionary<string, BitmapImage?> _memorie =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Returnează un BitmapImage din cache sau îl creează.
    /// • Cale relativă  → Images\fisier.jpg  (față de executabil)
    /// • Cale absolută  → C:\cale\fisier.jpg
    /// • URL HTTP/HTTPS → https://example.com/img.jpg  (WPF descarcă async)
    /// Returnează null dacă calea e goală sau fișierul nu există.
    /// </summary>
    public static BitmapImage? Incarca(string? cale)
    {
        if (string.IsNullOrWhiteSpace(cale)) return null;

        if (_memorie.TryGetValue(cale, out var cached)) return cached;

        try
        {
            Uri uri;

            if (cale.StartsWith("http://",  StringComparison.OrdinalIgnoreCase) ||
                cale.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                uri = new Uri(cale, UriKind.Absolute);
            }
            else
            {
                string calePlenara = Path.IsPathRooted(cale)
                    ? cale
                    : Path.Combine(AppContext.BaseDirectory, cale);

                if (!File.Exists(calePlenara))
                {
                    _memorie[cale] = null;
                    return null;
                }
                uri = new Uri(calePlenara, UriKind.Absolute);
            }

            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource    = uri;
            bitmap.CacheOption  = BitmapCacheOption.OnLoad;
            bitmap.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            bitmap.EndInit();
            bitmap.Freeze();   // thread-safe

            _memorie[cale] = bitmap;
            return bitmap;
        }
        catch
        {
            _memorie[cale] = null;
            return null;
        }
    }
}
